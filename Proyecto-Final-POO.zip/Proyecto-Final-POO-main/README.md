# Proyecto Final POO - Gestor Financiero

Integrantes del Grupo:

Emerson Alexis Mejia Cruz 20201900153

Gerzon Misael Flores Amaya 20201900042

Hector Josué Molina Fortín 20191900628

Zahir Imanol Alvarado Guerrero 20201900002
